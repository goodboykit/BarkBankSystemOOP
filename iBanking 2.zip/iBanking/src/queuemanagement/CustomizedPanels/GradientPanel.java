package queuemanagement.CustomizedPanels;

import javax.swing.JPanel;

public class GradientPanel extends JPanel {

}
